const express = require('express');
const bcrypt = require('bcrypt');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const app = express();

app.use(express.urlencoded({ extended: true }));

// 1. DATABASE SETUP
const db = new sqlite3.Database('./students.db', (err) => {
    if (err) console.error(err.message);
    console.log('Connected to the SQLite database.');
});

// Create the DBMS table
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password_hash TEXT
)`);

// 2. MAIN ROUTE (Login/Register Page)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// 3. LOGIN/STORE ROUTE: Hashes and inserts into DB
app.post('/login', async (req, res) => {
    const email = req.body.email;
    const passwordAttempt = req.body.password;
    const saltRounds = 10;
    
    try {
        const hashedPassword = await bcrypt.hash(passwordAttempt, saltRounds);

        const sql = `INSERT INTO users (email, password_hash) VALUES (?, ?)`;
        
        db.run(sql, [email, hashedPassword], function(err) {
            let statusMessage = "Data successfully stored in SQLite table!";
            if (err) {
                statusMessage = "Note: This email is already registered in the DB.";
            }

            res.send(`
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
                        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; justify-content: center; align-items: center; height: 100vh; }
                        .report-box { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.2); width: 100%; max-width: 500px; }
                        h2 { color: #2d3436; margin-bottom: 10px; text-align: center; }
                        .status { text-align: center; color: #27ae60; font-weight: bold; margin-bottom: 20px; font-size: 14px; }
                        .data-row { background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-left: 4px solid #667eea; }
                        .label { font-weight: bold; color: #636e72; font-size: 11px; text-transform: uppercase; display: block; margin-bottom: 5px; }
                        .value { font-family: 'Courier New', monospace; word-break: break-all; color: #2d3436; font-size: 14px; }
                        .btn-group { display: flex; gap: 10px; }
                        .btn { flex: 1; text-align: center; padding: 12px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px; }
                        .btn-primary { background: #667eea; color: white; }
                        .btn-secondary { background: #f1f2f6; color: #2d3436; }
                    </style>
                </head>
                <body>
                    <div class="report-box">
                        <h2>Hashing Success</h2>
                        <p class="status">✅ ${statusMessage}</p>
                        <div class="data-row">
                            <span class="label">Database Field: Email</span>
                            <span class="value">${email}</span>
                        </div>
                        <div class="data-row">
                            <span class="label">Database Field: Password Hash</span>
                            <span class="value">${hashedPassword}</span>
                        </div>
                        <div class="btn-group">
                            <a href="/" class="btn btn-secondary">Back</a>
                            <a href="/view-data" class="btn btn-primary">View Full Table</a>
                        </div>
                    </div>
                </body>
                </html>
            `);
        });
    } catch (error) {
        res.status(500).send("Hashing error.");
    }
});

// 4. VIEW DATA ROUTE: Shows the DBMS table
app.get('/view-data', (req, res) => {
    db.all("SELECT * FROM users", [], (err, rows) => {
        if (err) return res.send("Error reading database.");

        let tableRows = rows.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>${user.email}</td>
                <td class="hash-cell">${user.password_hash}</td>
            </tr>
        `).join('');

        res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    * { font-family: 'Segoe UI', sans-serif; }
                    body { background: #f4f7f6; padding: 50px; }
                    .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); max-width: 900px; margin: auto; }
                    h2 { color: #333; text-align: center; margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
                    th { background-color: #667eea; color: white; }
                    tr:nth-child(even) { background-color: #f9f9f9; }
                    .hash-cell { font-family: monospace; font-size: 11px; color: #d63031; word-break: break-all; }
                    .btn { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Student Database (SQLite)</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Password Hash (Bcrypt)</th>
                            </tr>
                        </thead>
                        <tbody>${tableRows}</tbody>
                    </table>
                    <a href="/" class="btn">Add New Student</a>
                </div>
            </body>
            </html>
        `);
    });
});

app.listen(3000, () => console.log('Server active at http://localhost:3000'));